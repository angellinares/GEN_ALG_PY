import math

#suelo de un numero
var1 = 4.58
var2 = math.floor(var1)
print var2

#factorial

print math.factorial(var2)

# sumamos los elementos de un iterable
lista1 = [1, 2.3, 3.4, 5]

print math.fsum(lista1)
