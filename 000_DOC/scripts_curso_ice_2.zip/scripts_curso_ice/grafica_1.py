import matplotlib.pyplot as plt

# primera grafica como una lista de datos
#plt.plot([-1, -4.5, 16, 23])
#plt.show()

# comentar lineas 4 y 5 antes de continuar
plt.plot([-1, -4.5, 16, 23], "ob") # ahora no tenemos una linea, tenemos puntos azules
plt.show()


