# definimos la funcion suma
def suma (a, b):
	resultado = a + b
	return resultado

# sumamos dos numeros
num1 = 10
num2 = 15

res = suma(num1, num2)
print res

# sumamos dos cadenas

cadena1 = "hola"
cadena2 = " mundo!"

res = suma(cadena1, cadena2)
print res

# sumamos dos listas

lista1 = [1, 2, 3]
lista2 = [4, 5, 6]

res = suma(lista1, lista2)
print res

# ejercicio propuesto1: realizar una funcion que multiple dos numeros
# ejercicio propuesto 2: realizar una funcion que reciba una cadena y devulva la longitud de la cadena





