#import random
#from random import uniform

def func(a, b, c= 3):
	print a, b, c

func(1,2)

