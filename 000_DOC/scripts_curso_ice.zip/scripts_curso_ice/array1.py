import numpy as np

# creamos una lista

lista = [1, 2, 3]

# hacemos la siguiente operacion

lista2 = lista * 3

print "Resultado de la multiplicacion con la lista"
print lista2

# ahora creamos un array con numpy

lista3 = np.arange(1, 4, 1)
lista4 = lista3 * 3

print "Resultado multiplicacion con el array"
print lista4

# si queremos hacer lo mismo con la lista tenemos que hacer algo asi
#for i in range(0, len(lista)):
#	lista[i] = lista[i] * 3

#print "Resultado despues del bucle"
#print lista

# bucle mas exotico

lista5 = [ i*3 for i in lista]
print "resultado despues del segundo bucle" 
print lista5

